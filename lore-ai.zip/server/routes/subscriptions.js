const express = require('express');
const db = require('../database');
const authMiddleware = require('../middleware/auth');
const router = express.Router();

const PLANS = {
  free: {
    id: 'free',
    name: 'Astra Free',
    price: 0,
    currency: 'USD',
    interval: 'forever',
    features: [
      'Unlimited text chats',
      'Full chat history',
      'Voice chat',
      'Photo attachments',
      '5 AI-generated photos per 24 hours',
      '2 AI-generated videos per 24 hours',
      'Student-safe responses'
    ],
    limits: { images: 5, videos: 2 }
  },
  pro: {
    id: 'pro',
    name: 'Astra Pro',
    price: 9.99,
    currency: 'USD',
    interval: 'month',
    features: [
      'Everything in Free',
      '50 AI-generated photos per 24 hours',
      '20 AI-generated videos per 24 hours',
      'Priority speed',
      'Longer voice chats',
      'Early access to new features'
    ],
    limits: { images: 50, videos: 20 }
  },
  ultra: {
    id: 'ultra',
    name: 'Astra Ultra',
    price: 19.99,
    currency: 'USD',
    interval: 'month',
    features: [
      'Everything in Pro',
      'Unlimited AI-generated photos',
      'Unlimited AI-generated videos',
      'Fastest generation speed',
      'Premium support',
      'Custom AI personality'
    ],
    limits: { images: Infinity, videos: Infinity }
  }
};

// Get all plans
router.get('/plans', (req, res) => {
  res.json(Object.values(PLANS));
});

// Get current user's plan and profile
router.get('/my-plan', authMiddleware, (req, res) => {
  const plan = PLANS[req.user.plan] || PLANS.free;
  res.json({
    id: plan.id,
    name: req.user.name,
    email: req.user.email,
    plan: req.user.plan,
    planName: plan.name,
    planPrice: plan.price,
    planFeatures: plan.features,
    limits: plan.limits
  });
});

// Upgrade/change plan
// In production this should only be triggered by verified payment webhooks.
// For testing, set ALLOW_DIRECT_UPGRADE=true in .env to allow direct upgrades.
router.post('/upgrade', authMiddleware, (req, res) => {
  const { plan } = req.body;
  if (!PLANS[plan]) {
    return res.status(400).json({ error: 'Invalid plan.' });
  }

  if (process.env.ALLOW_DIRECT_UPGRADE !== 'true') {
    return res.status(403).json({
      error: 'Direct upgrades are disabled. Please use the payment checkout flow.'
    });
  }

  db.run('UPDATE users SET plan = ? WHERE id = ?', [plan, req.user.id], function(err) {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to update plan.' });
    }
    res.json({ success: true, plan: PLANS[plan] });
  });
});

module.exports = router;
