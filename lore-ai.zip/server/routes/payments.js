const express = require('express');
const Stripe = require('stripe');
const Razorpay = require('razorpay');
const crypto = require('crypto');
const db = require('../database');
const authMiddleware = require('../middleware/auth');
const router = express.Router();

const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY) : null;
const razorpay = (process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET)
  ? new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET })
  : null;

const PLAN_PRICES = {
  stripe: {
    pro: process.env.STRIPE_PRICE_PRO,
    ultra: process.env.STRIPE_PRICE_ULTRA
  },
  razorpay: {
    pro: 999,   // ₹999 INR (or $9.99 USD in cents if using Razorpay international)
    ultra: 1999 // ₹1999 INR
  }
};

const PLAN_NAMES = {
  pro: 'Astra Pro',
  ultra: 'Astra Ultra'
};

// ==================== STRIPE ====================

// Create a Stripe Checkout session
router.post('/stripe/create-checkout-session', authMiddleware, async (req, res) => {
  try {
    if (!stripe) {
      return res.status(400).json({ error: 'Stripe is not configured. Please set STRIPE_SECRET_KEY.' });
    }

    const { plan } = req.body;
    if (!PLAN_NAMES[plan]) {
      return res.status(400).json({ error: 'Invalid plan.' });
    }

    const priceId = PLAN_PRICES.stripe[plan];
    if (!priceId) {
      return res.status(400).json({ error: `Stripe price ID not configured for ${plan} plan.` });
    }

    const session = await stripe.checkout.sessions.create({
      customer_email: req.user.email,
      line_items: [
        {
          price: priceId,
          quantity: 1
        }
      ],
      mode: 'subscription',
      metadata: {
        userId: req.user.id,
        plan: plan
      },
      success_url: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/subscriptions?payment=success&plan=${plan}&provider=stripe`,
      cancel_url: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/subscriptions?payment=cancelled`
    });

    res.json({ sessionId: session.id, url: session.url });
  } catch (err) {
    console.error('Stripe checkout error:', err);
    res.status(500).json({ error: err.message || 'Failed to create Stripe checkout session.' });
  }
});

// Stripe webhook (raw body required)
router.post('/stripe/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Stripe webhook signature error:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const userId = session.metadata?.userId;
    const plan = session.metadata?.plan;

    if (userId && plan) {
      upgradeUserPlan(userId, plan, (err) => {
        if (err) console.error('Failed to upgrade user after Stripe payment:', err);
      });
    }
  }

  res.json({ received: true });
});

// ==================== RAZORPAY ====================

// Create a Razorpay order
router.post('/razorpay/create-order', authMiddleware, async (req, res) => {
  try {
    if (!razorpay) {
      return res.status(400).json({ error: 'Razorpay is not configured. Please set RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET.' });
    }

    const { plan } = req.body;
    if (!PLAN_NAMES[plan]) {
      return res.status(400).json({ error: 'Invalid plan.' });
    }

    const amount = PLAN_PRICES.razorpay[plan]; // amount in smallest currency unit (INR paise)
    const options = {
      amount: amount * 100,
      currency: 'INR',
      receipt: `order_${plan}_${req.user.id}_${Date.now()}`,
      notes: {
        userId: req.user.id,
        plan: plan,
        email: req.user.email
      }
    };

    const order = await razorpay.orders.create(options);
    res.json({
      orderId: order.id,
      amount: options.amount,
      currency: options.currency,
      keyId: process.env.RAZORPAY_KEY_ID,
      plan: plan,
      name: PLAN_NAMES[plan]
    });
  } catch (err) {
    console.error('Razorpay order error:', err);
    res.status(500).json({ error: err.message || 'Failed to create Razorpay order.' });
  }
});

// Verify Razorpay payment and upgrade user
router.post('/razorpay/verify', authMiddleware, async (req, res) => {
  try {
    const { orderId, paymentId, signature, plan } = req.body;
    if (!orderId || !paymentId || !signature || !plan) {
      return res.status(400).json({ error: 'Missing payment details.' });
    }

    // Verify signature
    const expectedSignature = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
      .update(`${orderId}|${paymentId}`)
      .digest('hex');

    if (expectedSignature !== signature) {
      return res.status(400).json({ error: 'Invalid payment signature. Payment verification failed.' });
    }

    upgradeUserPlan(req.user.id, plan, (err) => {
      if (err) {
        console.error('Failed to upgrade user after Razorpay payment:', err);
        return res.status(500).json({ error: 'Payment verified but failed to upgrade plan. Contact support.' });
      }
      res.json({ success: true, message: 'Payment verified and plan upgraded!' });
    });
  } catch (err) {
    console.error('Razorpay verify error:', err);
    res.status(500).json({ error: err.message || 'Failed to verify Razorpay payment.' });
  }
});

// Get public payment config
router.get('/config', (req, res) => {
  res.json({
    stripePublishableKey: process.env.STRIPE_PUBLISHABLE_KEY || null,
    razorpayKeyId: process.env.RAZORPAY_KEY_ID || null
  });
});

// ==================== Helpers ====================

function upgradeUserPlan(userId, plan, callback) {
  db.run('UPDATE users SET plan = ? WHERE id = ?', [plan, userId], function(err) {
    if (err) return callback(err);
    callback(null, { changes: this.changes });
  });
}

module.exports = router;
