const express = require('express');
const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const db = require('../database');
const authMiddleware = require('../middleware/auth');
const { isStudentSafe } = require('./chat');
const router = express.Router();

const UPLOAD_DIR = process.env.NODE_ENV === 'production'
  ? path.resolve(__dirname, '..', '..', 'data', 'uploads')
  : path.resolve(__dirname, '..', '..', 'uploads');
const PUBLIC_UPLOAD_DIR = '/uploads';

function escapeXml(text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

// Multer setup for photo uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || '.png';
    cb(null, `${uuidv4()}${ext}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB max
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    if (allowed.includes(file.mimetype)) cb(null, true);
    else cb(new Error('Only JPG, PNG, WebP, and GIF images are allowed.'));
  }
});

// Plan limits
const LIMITS = {
  free: { images: 5, videos: 2 },
  pro: { images: 50, videos: 20 },
  ultra: { images: 999999, videos: 999999 }
};

// Get usage in the last 24 hours
function getUsage(userId, type, callback) {
  const since = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
  db.get(
    'SELECT COUNT(*) AS count FROM usage_logs WHERE user_id = ? AND type = ? AND created_at > ?',
    [userId, type, since],
    (err, row) => {
      if (err) return callback(err, null);
      callback(null, row.count);
    }
  );
}

function logUsage(userId, type, callback) {
  db.run('INSERT INTO usage_logs (user_id, type) VALUES (?, ?)', [userId, type], callback);
}

// Check limits middleware
function checkLimit(type) {
  return (req, res, next) => {
    const userPlan = req.user.plan || 'free';
    const limit = LIMITS[userPlan]?.[type] ?? LIMITS.free[type];

    getUsage(req.user.id, type, (err, count) => {
      if (err) return res.status(500).json({ error: 'Failed to check usage.' });
      if (count >= limit) {
        return res.status(429).json({
          error: `You have reached your ${type} limit for the free plan (${limit} per 24 hours). Please upgrade to Pro or Ultra.`,
          limit,
          used: count,
          upgradeRecommended: true
        });
      }
      req.currentUsage = count;
      req.usageLimit = limit;
      next();
    });
  };
}

// Get current usage stats
router.get('/usage', authMiddleware, (req, res) => {
  const userPlan = req.user.plan || 'free';
  const limits = LIMITS[userPlan] || LIMITS.free;
  const result = { plan: userPlan, limits: {} };

  let pending = 2;
  ['images', 'videos'].forEach(type => {
    getUsage(req.user.id, type, (err, count) => {
      result.limits[type] = { used: count, limit: limits[type] };
      pending--;
      if (pending === 0) res.json(result);
    });
  });
});

// Text-to-image
router.post('/generate/image', authMiddleware, checkLimit('images'), async (req, res) => {
  const { prompt } = req.body;
  if (!prompt || !prompt.trim()) {
    return res.status(400).json({ error: 'Prompt is required.' });
  }
  if (!isStudentSafe(prompt)) {
    return res.status(400).json({ error: 'Prompt was blocked by student-safety filters.' });
  }

  // In production: call DALL-E, Stable Diffusion, or Replicate here
  // Mock: generate a colored placeholder SVG image
  // In production, replace this with a real image API (DALL-E, Stable Diffusion, etc.)
  const id = uuidv4();
  const filename = `${id}.svg`;
  const filepath = path.join(UPLOAD_DIR, filename);
  const hue = Math.floor(Math.random() * 360);
  const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512">
  <rect width="100%" height="100%" fill="hsl(${hue}, 70%, 80%)"/>
  <text x="50%" y="40%" font-family="sans-serif" font-size="22" fill="#333" text-anchor="middle">Lore.Ai Image</text>
  <text x="50%" y="60%" font-family="sans-serif" font-size="16" fill="#555" text-anchor="middle">${escapeXml(prompt.slice(0, 40))}${prompt.length > 40 ? '...' : ''}</text>
</svg>`;

  const fs = require('fs');
  fs.writeFileSync(filepath, svg);

  logUsage(req.user.id, 'images', (err) => {
    if (err) console.error('Failed to log image usage:', err);
  });

  res.json({
    success: true,
    type: 'image',
    url: `${PUBLIC_UPLOAD_DIR}/${filename}`,
    prompt: prompt.trim(),
    remaining: req.usageLimit - req.currentUsage - 1
  });
});

// Text-to-video
router.post('/generate/video', authMiddleware, checkLimit('videos'), async (req, res) => {
  const { prompt, source = 'text' } = req.body;
  if (!prompt || !prompt.trim()) {
    return res.status(400).json({ error: 'Prompt is required.' });
  }
  if (!isStudentSafe(prompt)) {
    return res.status(400).json({ error: 'Prompt was blocked by student-safety filters.' });
  }

  // In production: call Runway, Pika, Kling, or Replicate here
  // Mock: return an animated placeholder video URL (using a public demo MP4)
  logUsage(req.user.id, 'videos', (err) => {
    if (err) console.error('Failed to log video usage:', err);
  });

  res.json({
    success: true,
    type: 'video',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    prompt: prompt.trim(),
    source,
    remaining: req.usageLimit - req.currentUsage - 1,
    note: 'This is a mock video. In production, integrate a real text-to-video API like Runway Gen-3, Pika, or Replicate.'
  });
});

// Photo-to-video (upload image first, then generate video)
router.post('/generate/photo-to-video', authMiddleware, upload.single('image'), checkLimit('videos'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'Please upload an image.' });
  }

  // In production: send the uploaded image to an image-to-video model
  logUsage(req.user.id, 'videos', (err) => {
    if (err) console.error('Failed to log video usage:', err);
  });

  res.json({
    success: true,
    type: 'video',
    sourceImage: `${PUBLIC_UPLOAD_DIR}/${req.file.filename}`,
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    remaining: req.usageLimit - req.currentUsage - 1,
    note: 'This is a mock video. In production, integrate an image-to-video API like Runway, Pika, or Kling.'
  });
});

// Upload photo for chat attachment
router.post('/upload', authMiddleware, upload.single('image'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'Please upload an image.' });
  }
  res.json({ url: `${PUBLIC_UPLOAD_DIR}/${req.file.filename}` });
});

module.exports = router;
