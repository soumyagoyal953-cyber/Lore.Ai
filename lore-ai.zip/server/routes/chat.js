const express = require('express');
const db = require('../database');
const authMiddleware = require('../middleware/auth');
const router = express.Router();

const STUDENT_SAFE_PROMPT = `
You are Lore.Ai, a helpful, friendly, and student-safe AI assistant created with love by Soumya Goyal.
Rules:
1. Never produce harmful, explicit, violent, or unsafe content.
2. Keep responses appropriate for students aged 13+.
3. Refuse requests to generate inappropriate content, bullying, hate speech, or dangerous instructions.
4. Be encouraging and helpful.
`;

// Generate a simple title from first user message
function generateTitle(message) {
  const cleaned = message.replace(/\s+/g, ' ').trim();
  return cleaned.length > 30 ? cleaned.slice(0, 27) + '...' : cleaned || 'New Chat';
}

// Student safety filter
function isStudentSafe(text) {
  const forbidden = [
    'kill', 'murder', 'suicide', 'self-harm', 'porn', 'nude', 'naked', 'sex',
    'drug', 'cocaine', 'heroin', 'meth', 'bomb', 'terrorist', 'how to make a weapon',
    'hate', 'racist', 'bully', 'abuse'
  ];
  const lower = text.toLowerCase();
  return !forbidden.some(word => lower.includes(word));
}

// Mock AI response
function generateMockResponse(userMessage) {
  const lower = userMessage.toLowerCase();

  if (lower.includes('hello') || lower.includes('hi')) {
    return "Hi there! I'm Lore.Ai, your student-safe assistant. How can I help you today?";
  }
  if (lower.includes('help')) {
    return "I can help with homework, answer questions, write stories, summarize text, and more. What do you need?";
  }
  if (lower.includes('who are you') || lower.includes('your name') || lower.includes('what is your name') || lower.includes('what\'s your name')) {
    return "Hello there and welcome! My name is Lore.Ai. I'm created by a 13 year old girl SOUMYA GOYAL.";
  }
  if (lower.includes('math')) {
    return "Math is awesome! Whether it's algebra, geometry, or arithmetic, I can walk you through step by step. What problem are you stuck on?";
  }
  if (lower.includes('code') || lower.includes('programming')) {
    return "I love coding! I can help you understand concepts, debug code, or explain algorithms. What language or topic?";
  }
  if (lower.includes('image') || lower.includes('picture') || lower.includes('photo')) {
    return "I can help you generate images! Use the attachment/photo button or the media options. Free users get 5 photos per 24 hours.";
  }
  if (lower.includes('video')) {
    return "I can create videos from text or photos! Free users can make 2 videos every 24 hours. Upgrade your plan for more.";
  }
  return `That's an interesting question about "${userMessage.slice(0, 40)}${userMessage.length > 40 ? '...' : ''}". As Lore.Ai, I'm here to help you explore it safely. Could you tell me a bit more?`;
}

// Create a new chat session
router.post('/sessions', authMiddleware, (req, res) => {
  db.run(
    'INSERT INTO chat_sessions (user_id, title) VALUES (?, ?)',
    [req.user.id, 'New Chat'],
    function(err) {
      if (err) return res.status(500).json({ error: 'Failed to create session.' });
      res.status(201).json({ id: this.lastID, title: 'New Chat', created_at: new Date().toISOString() });
    }
  );
});

// Get all sessions for user
router.get('/sessions', authMiddleware, (req, res) => {
  db.all(
    'SELECT id, title, created_at, updated_at FROM chat_sessions WHERE user_id = ? ORDER BY updated_at DESC',
    [req.user.id],
    (err, rows) => {
      if (err) return res.status(500).json({ error: 'Failed to load sessions.' });
      res.json(rows);
    }
  );
});

// Get messages in a session
router.get('/sessions/:id/messages', authMiddleware, (req, res) => {
  const sessionId = req.params.id;
  db.get('SELECT id FROM chat_sessions WHERE id = ? AND user_id = ?', [sessionId, req.user.id], (err, session) => {
    if (err || !session) return res.status(404).json({ error: 'Chat not found.' });

    db.all(
      'SELECT id, role, content, type, attachment_url, created_at FROM messages WHERE session_id = ? ORDER BY created_at ASC',
      [sessionId],
      (err, rows) => {
        if (err) return res.status(500).json({ error: 'Failed to load messages.' });
        res.json(rows);
      }
    );
  });
});

// Send a message and get AI response
router.post('/sessions/:id/messages', authMiddleware, (req, res) => {
  const sessionId = req.params.id;
  const { content, attachment_url, type = 'text' } = req.body;

  if (!content || typeof content !== 'string' || content.trim().length === 0) {
    return res.status(400).json({ error: 'Message content is required.' });
  }

  if (!isStudentSafe(content)) {
    return res.status(400).json({ error: 'This message was blocked by student-safety filters. Please keep your request appropriate for school.' });
  }

  db.get('SELECT id, title FROM chat_sessions WHERE id = ? AND user_id = ?', [sessionId, req.user.id], (err, session) => {
    if (err || !session) return res.status(404).json({ error: 'Chat not found.' });

    const userContent = content.trim();
    const now = new Date().toISOString();

    // Update title if it's still the default
    let titleUpdatePromise = Promise.resolve();
    if (session.title === 'New Chat') {
      const newTitle = generateTitle(userContent);
      titleUpdatePromise = new Promise((resolve, reject) => {
        db.run('UPDATE chat_sessions SET title = ?, updated_at = ? WHERE id = ?', [newTitle, now, sessionId], function(err) {
          if (err) reject(err);
          else resolve();
        });
      });
    } else {
      titleUpdatePromise = new Promise((resolve, reject) => {
        db.run('UPDATE chat_sessions SET updated_at = ? WHERE id = ?', [now, sessionId], function(err) {
          if (err) reject(err);
          else resolve();
        });
      });
    }

    titleUpdatePromise.then(() => {
      db.run(
        'INSERT INTO messages (session_id, user_id, role, content, type, attachment_url) VALUES (?, ?, ?, ?, ?, ?)',
        [sessionId, req.user.id, 'user', userContent, type, attachment_url || null],
        function(err) {
          if (err) return res.status(500).json({ error: 'Failed to save message.' });

          const userMessageId = this.lastID;

          // Generate assistant response
          const aiResponse = generateMockResponse(userContent);
          db.run(
            'INSERT INTO messages (session_id, user_id, role, content, type) VALUES (?, ?, ?, ?, ?)',
            [sessionId, req.user.id, 'assistant', aiResponse, 'text'],
            function(err) {
              if (err) return res.status(500).json({ error: 'Failed to save AI response.' });

              res.json({
                userMessage: { id: userMessageId, role: 'user', content: userContent, type, attachment_url },
                assistantMessage: { id: this.lastID, role: 'assistant', content: aiResponse, type: 'text' }
              });
            }
          );
        }
      );
    }).catch(err => {
      console.error(err);
      res.status(500).json({ error: 'Failed to update session.' });
    });
  });
});

// Delete a session
router.delete('/sessions/:id', authMiddleware, (req, res) => {
  const sessionId = req.params.id;
  db.run('DELETE FROM chat_sessions WHERE id = ? AND user_id = ?', [sessionId, req.user.id], function(err) {
    if (err) return res.status(500).json({ error: 'Failed to delete chat.' });
    res.json({ success: true, deleted: this.changes });
  });
});

module.exports = { router, isStudentSafe };
