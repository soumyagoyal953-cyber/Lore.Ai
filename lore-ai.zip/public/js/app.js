/*****************************
 * Lore.Ai Frontend App
 * Created with love by Soumya Goyal
 *****************************/

const API_BASE = '';
let currentUser = null;
let token = localStorage.getItem('astra_token');
let currentSessionId = null;
let isRecording = false;
let recognition = null;
let currentAttachment = null;
let mediaMenuOpen = false;

// Initialize
async function init() {
  if (token) {
    try {
      const user = await apiGet('/api/subscriptions/my-plan');
      currentUser = { ...user, plan: user.id };
      loadRoute();
    } catch (err) {
      logout();
    }
  } else {
    loadRoute();
  }
}

// API helpers
async function api(url, options = {}) {
  const headers = {
    'Content-Type': 'application/json',
    ...(token && { Authorization: `Bearer ${token}` })
  };

  const res = await fetch(`${API_BASE}${url}`, {
    ...options,
    headers: {
      ...headers,
      ...(options.headers || {})
    }
  });

  const data = await res.json().catch(() => null);
  if (!res.ok) {
    throw new Error(data?.error || `Request failed: ${res.status}`);
  }
  return data;
}

function apiGet(url) { return api(url, { method: 'GET' }); }
function apiPost(url, body) { return api(url, { method: 'POST', body: JSON.stringify(body) }); }
function apiDelete(url) { return api(url, { method: 'DELETE' }); }

// FormData API for uploads
async function apiUpload(url, formData) {
  const res = await fetch(`${API_BASE}${url}`, {
    method: 'POST',
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    body: formData
  });
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new Error(data?.error || `Upload failed: ${res.status}`);
  return data;
}

// Routing
function loadRoute() {
  const path = window.location.pathname.replace(/^\//, '') || 'landing';
  const app = document.getElementById('app');
  app.innerHTML = '';

  if (token && currentUser) {
    if (path === 'subscriptions') {
      renderSubscriptions(app);
    } else {
      renderChat(app);
    }
  } else {
    if (path === 'login') renderLogin(app);
    else if (path === 'signup') renderSignup(app);
    else renderLanding(app);
  }
}

function navigate(path) {
  window.history.pushState({}, '', `/${path}`);
  loadRoute();
}

window.addEventListener('popstate', loadRoute);

// Toast notifications
function showToast(message, type = 'success', duration = 4000) {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <span>${message}</span>
    <button class="toast-close" onclick="this.parentElement.remove()">✕</button>
  `;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), duration);
}

// Auth handlers
async function handleLogin(e) {
  e.preventDefault();
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;
  const errorEl = document.getElementById('login-error');
  errorEl.textContent = '';

  try {
    const data = await apiPost('/api/auth/login', { email, password });
    token = data.token;
    currentUser = data.user;
    localStorage.setItem('astra_token', token);
    navigate('chat');
    showToast(`Welcome back, ${currentUser.name}!`, 'success');
  } catch (err) {
    errorEl.textContent = err.message;
  }
}

async function handleSignup(e) {
  e.preventDefault();
  const name = document.getElementById('signup-name').value;
  const email = document.getElementById('signup-email').value;
  const password = document.getElementById('signup-password').value;
  const confirm = document.getElementById('signup-confirm').value;
  const errorEl = document.getElementById('signup-error');
  errorEl.textContent = '';

  if (password !== confirm) {
    errorEl.textContent = 'Passwords do not match.';
    return;
  }

  try {
    const data = await apiPost('/api/auth/signup', { name, email, password });
    token = data.token;
    currentUser = data.user;
    localStorage.setItem('astra_token', token);
    navigate('chat');
    showToast('Welcome to Lore.Ai!', 'success');
  } catch (err) {
    errorEl.textContent = err.message;
  }
}

function logout() {
  token = null;
  currentUser = null;
  currentSessionId = null;
  localStorage.removeItem('astra_token');
  navigate('landing');
}

// Views
function renderLanding(container) {
  container.innerHTML = `
    <div class="landing-page">
      <img src="/images/astra-icon.png" alt="Lore.Ai" class="app-icon-large" />
      <div class="landing-logo">Lore.Ai</div>
      <p class="landing-tagline">Your student-safe AI assistant for homework, creativity, and curiosity.</p>
      <div class="creator-card">
        <div class="heart">❤️</div>
        <p style="margin-top: 0.5rem; font-size: 1.1rem;">Created with love by a 13 year old</p>
        <p style="font-size: 1.5rem; font-weight: 700; margin-top: 0.25rem; color: var(--accent);">SOUMYA GOYAL</p>
      </div>
      <div class="landing-buttons">
        <button class="btn btn-primary" onclick="navigate('signup')">Get Started</button>
        <button class="btn btn-secondary" onclick="navigate('login')">Login</button>
      </div>
      <div class="feature-grid" style="margin-top: 3rem;">
        <div class="feature-card">
          <h3>💬 Smart Chat</h3>
          <p>Ask anything, get helpful, student-safe answers instantly.</p>
        </div>
        <div class="feature-card">
          <h3>🎨 AI Images</h3>
          <p>Generate photos from text. 5 free images every 24 hours.</p>
        </div>
        <div class="feature-card">
          <h3>🎬 AI Videos</h3>
          <p>Text-to-video and photo-to-video. 2 free videos per day.</p>
        </div>
        <div class="feature-card">
          <h3>🎙️ Voice Chat</h3>
          <p>Talk to Astra with your voice. Perfect for hands-free learning.</p>
        </div>
        <div class="feature-card">
          <h3>📎 Attach Photos</h3>
          <p>Share images in your chat for richer conversations.</p>
        </div>
        <div class="feature-card">
          <h3>🛡️ Student Safe</h3>
          <p>Built-in safety filters keep content appropriate for all ages.</p>
        </div>
      </div>
    </div>
  `;
}

function renderLogin(container) {
  container.innerHTML = `
    <div class="auth-page">
      <div class="auth-card">
        <h2>Welcome back</h2>
        <p>Login to Lore.Ai</p>
        <form id="login-form">
          <div class="form-group">
            <label for="login-email">Email</label>
            <input type="email" id="login-email" required placeholder="you@example.com" />
          </div>
          <div class="form-group">
            <label for="login-password">Password</label>
            <input type="password" id="login-password" required placeholder="••••••••" />
          </div>
          <div class="error-text" id="login-error"></div>
          <button type="submit" class="btn btn-primary">Login</button>
        </form>
        <div class="auth-footer">
          Don't have an account? <a onclick="navigate('signup')">Sign up</a>
        </div>
        <div class="auth-footer mt-1">
          <a onclick="navigate('landing')">← Back to home</a>
        </div>
      </div>
    </div>
  `;
  document.getElementById('login-form').addEventListener('submit', handleLogin);
}

function renderSignup(container) {
  container.innerHTML = `
    <div class="auth-page">
      <div class="auth-card">
        <h2>Create account</h2>
        <p>Join Lore.Ai today</p>
        <form id="signup-form">
          <div class="form-group">
            <label for="signup-name">Full Name</label>
            <input type="text" id="signup-name" required placeholder="Your name" />
          </div>
          <div class="form-group">
            <label for="signup-email">Email</label>
            <input type="email" id="signup-email" required placeholder="you@example.com" />
          </div>
          <div class="form-group">
            <label for="signup-password">Password</label>
            <input type="password" id="signup-password" required placeholder="At least 6 characters" minlength="6" />
          </div>
          <div class="form-group">
            <label for="signup-confirm">Confirm Password</label>
            <input type="password" id="signup-confirm" required placeholder="••••••••" />
          </div>
          <div class="error-text" id="signup-error"></div>
          <button type="submit" class="btn btn-primary">Sign Up</button>
        </form>
        <div class="auth-footer">
          Already have an account? <a onclick="navigate('login')">Login</a>
        </div>
        <div class="auth-footer mt-1">
          <a onclick="navigate('landing')">← Back to home</a>
        </div>
      </div>
    </div>
  `;
  document.getElementById('signup-form').addEventListener('submit', handleSignup);
}

async function renderChat(container) {
  container.innerHTML = `
    <div class="page">
      <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
          <div class="sidebar-logo"><img src="/images/astra-icon.png" alt="Lore.Ai" /> Lore.Ai</div>
          <button class="btn btn-secondary new-chat-btn" onclick="createNewSession()">
            <span>＋</span> New chat
          </button>
        </div>
        <div class="sidebar-history" id="history-list">
          <div class="text-center" style="padding: 1rem; color: var(--text-secondary);">Loading...</div>
        </div>
        <div class="sidebar-footer">
          <button class="btn btn-secondary btn-small" style="width:100%; justify-content:flex-start;" onclick="navigate('subscriptions')">
            ⭐ Upgrade Plan
          </button>
          <div class="user-info">
            <div class="user-avatar">${(currentUser?.name || 'U').charAt(0).toUpperCase()}</div>
            <div style="flex:1; min-width:0;">
              <div style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${escapeHtml(currentUser?.name || 'User')}</div>
              <div style="font-size:0.75rem; color:var(--text-secondary);">${escapeHtml(currentUser?.email || '')}</div>
            </div>
            <span class="plan-badge">${currentUser?.plan || 'free'}</span>
          </div>
          <button class="btn btn-danger btn-small" style="width:100%;" onclick="logout()">Logout</button>
        </div>
      </aside>
      <div class="main" id="chat-main">
        <div class="chat-header">
          <div style="display:flex; align-items:center; gap:0.5rem;">
            <button class="icon-btn mobile-menu-btn" onclick="toggleSidebar()">☰</button>
            <img src="/images/astra-icon.png" alt="Lore.Ai" class="chat-header-icon" />
            <span class="chat-header-title" id="chat-title">Lore.Ai</span>
          </div>
          <div class="header-actions">
            <button class="icon-btn ${isRecording ? 'recording' : ''}" id="voice-btn" title="Voice chat" onclick="toggleVoice()">
              🎙️
            </button>
            <button class="icon-btn" title="Subscriptions" onclick="navigate('subscriptions')">
              ⭐
            </button>
          </div>
        </div>
        <div class="messages" id="messages">
          <div class="empty-state">
            <h1>Lore.Ai</h1>
            <p>How can I help you today?</p>
            <div class="feature-grid">
              <div class="feature-card" onclick="setInput('Explain a math problem step by step')">
                <h3>📚 Homework Help</h3>
                <p>"Explain a math problem step by step"</p>
              </div>
              <div class="feature-card" onclick="setInput('Generate an image of a friendly robot')">
                <h3>🎨 Image Idea</h3>
                <p>"Generate an image of a friendly robot"</p>
              </div>
              <div class="feature-card" onclick="setInput('Create a video of a sunset beach')">
                <h3>🎬 Video Idea</h3>
                <p>"Create a video of a sunset beach"</p>
              </div>
              <div class="feature-card" onclick="setInput('Write a short poem about space')">
                <h3>✍️ Creative Writing</h3>
                <p>"Write a short poem about space"</p>
              </div>
            </div>
          </div>
        </div>
        <div class="input-area" style="position:relative;">
          <div class="media-menu" id="media-menu">
            <button class="media-option" onclick="generateImageFromInput()">🎨 Text to Image</button>
            <button class="media-option" onclick="generateVideoFromInput()">🎬 Text to Video</button>
            <button class="media-option" onclick="document.getElementById('video-image-input').click()">🖼️ Photo to Video</button>
          </div>
          <div id="attachment-preview" class="hidden" style="margin-bottom:0.5rem;"></div>
          <div class="input-container">
            <textarea id="chat-input" rows="1" placeholder="Message Lore.Ai..." onkeydown="handleInputKey(event)" oninput="autoResize(this)"></textarea>
            <div class="input-actions">
              <div class="input-left">
                <button class="icon-btn" title="Attach photo" onclick="document.getElementById('image-input').click()">
                  📎
                </button>
                <button class="icon-btn" title="Generate media" onclick="toggleMediaMenu()">
                  🎨
                </button>
                <span class="input-hint">Created with love by Soumya Goyal</span>
              </div>
              <div class="input-right">
                <button class="send-btn" id="send-btn" onclick="sendMessage()">
                  ➤
                </button>
              </div>
            </div>
          </div>
          <input type="file" id="image-input" class="hidden" accept="image/*" onchange="handleImageUpload(event)">
          <input type="file" id="video-image-input" class="hidden" accept="image/*" onchange="handlePhotoToVideo(event)">
        </div>
      </div>
    </div>
  `;

  await loadHistory();
  if (!currentSessionId) {
    const recent = document.querySelector('.history-item');
    if (recent) {
      const onclick = recent.getAttribute('onclick');
      const match = onclick.match(/openSession\((\d+)\)/);
      if (match) {
        openSession(parseInt(match[1]));
      }
    } else {
      await createNewSession();
    }
  }
  setupVoiceRecognition();
}

async function renderSubscriptions(container) {
  // Check for payment return query params
  const urlParams = new URLSearchParams(window.location.search);
  const paymentStatus = urlParams.get('payment');
  const paymentPlan = urlParams.get('plan');

  if (paymentStatus === 'success' && paymentPlan) {
    try {
      const updated = await apiGet('/api/subscriptions/my-plan');
      currentUser = { ...updated, plan: updated.plan };
      showToast(`🎉 Payment successful! You're on the ${escapeHtml(paymentPlan)} plan.`, 'success');
    } catch (err) {
      console.error('Failed to refresh profile after payment:', err);
    }
    window.history.replaceState({}, '', '/subscriptions');
  } else if (paymentStatus === 'cancelled') {
    showToast('Payment cancelled. You can try again anytime.', 'warning');
    window.history.replaceState({}, '', '/subscriptions');
  }

  container.innerHTML = `
    <div class="subscriptions-page">
      <div class="subscriptions-header">
        <h1>Choose your Lore.Ai plan</h1>
        <p>Upgrade to unlock more AI-generated photos and videos.</p>
        <button class="btn btn-secondary btn-small mt-2" onclick="navigate('chat')">← Back to Chat</button>
      </div>
      <div id="plans-container" class="plans-grid">
        <div class="text-center" style="grid-column:1/-1; color:var(--text-secondary);">Loading plans...</div>
      </div>
      <div id="payment-note" class="plans-grid" style="margin-top:1rem; display:none;">
        <div class="plan-card" style="grid-column:1/-1;">
          <p style="color:var(--text-secondary); font-size:0.9rem;">
            Choose your preferred payment method. Both Stripe (cards) and Razorpay (UPI/cards) are supported.
          </p>
        </div>
      </div>
      <div id="usage-container" class="plans-grid" style="margin-top:2rem;"></div>
    </div>
  `;

  try {
    const [plans, usage, paymentConfig] = await Promise.all([
      apiGet('/api/subscriptions/plans'),
      apiGet('/api/media/usage'),
      apiGet('/api/payments/config').catch(() => ({ stripePublishableKey: null, razorpayKeyId: null }))
    ]);

    window.astraPaymentConfig = paymentConfig;

    const hasStripe = isRealKey(paymentConfig.stripePublishableKey, 'pk_test');
    const hasRazorpay = isRealKey(paymentConfig.razorpayKeyId, 'rzp_test');
    if (hasStripe || hasRazorpay) {
      document.getElementById('payment-note').style.display = 'grid';
    }

    const plansContainer = document.getElementById('plans-container');
    plansContainer.innerHTML = plans.map(plan => {
      const isCurrent = currentUser?.plan === plan.id;
      const canPay = plan.id !== 'free' && !isCurrent && (hasStripe || hasRazorpay);

      let actionButtons = '';
      if (isCurrent) {
        actionButtons = '<button class="btn btn-secondary" disabled>Current Plan</button>';
      } else if (plan.id === 'free') {
        actionButtons = '<button class="btn btn-secondary" disabled>Included</button>';
      } else if (canPay) {
        actionButtons = `
          <div style="display:flex; flex-direction:column; gap:0.5rem;">
            ${hasStripe ? `<button class="btn btn-primary" onclick="payWithStripe('${plan.id}')">Pay with Stripe (Card)</button>` : ''}
            ${hasRazorpay ? `<button class="btn btn-secondary" onclick="payWithRazorpay('${plan.id}', '${escapeHtml(plan.name)}', ${plan.price})">Pay with Razorpay (UPI/Card)</button>` : ''}
          </div>
        `;
      } else {
        actionButtons = '<button class="btn btn-secondary" disabled>Payment not configured</button>';
      }

      const priceDisplay = plan.price === 0 ? 'Free' : `$${plan.price}`;
      const intervalDisplay = plan.interval === 'forever' ? '' : `/${plan.interval}`;

      return `
        <div class="plan-card ${isCurrent ? 'current' : ''}">
          <h2>${escapeHtml(plan.name)}</h2>
          <div class="plan-price">${priceDisplay}<span>${intervalDisplay}</span></div>
          <ul class="plan-features">
            ${plan.features.map(f => `<li>${escapeHtml(f)}</li>`).join('')}
          </ul>
          ${actionButtons}
        </div>
      `;
    }).join('');

    const usageContainer = document.getElementById('usage-container');
    usageContainer.innerHTML = `
      <div class="plan-card" style="grid-column:1/-1;">
        <h2>Your 24-Hour Usage</h2>
        <div class="usage-bar">
          <label><span>AI Photos</span><span>${usage.limits.images.used} / ${usage.limits.images.limit}</span></label>
          <div class="usage-track">
            <div class="usage-fill ${getUsageClass(usage.limits.images.used, usage.limits.images.limit)}" style="width:${getUsagePercent(usage.limits.images.used, usage.limits.images.limit)}%"></div>
          </div>
        </div>
        <div class="usage-bar">
          <label><span>AI Videos</span><span>${usage.limits.videos.used} / ${usage.limits.videos.limit}</span></label>
          <div class="usage-track">
            <div class="usage-fill ${getUsageClass(usage.limits.videos.used, usage.limits.videos.limit)}" style="width:${getUsagePercent(usage.limits.videos.used, usage.limits.videos.limit)}%"></div>
          </div>
        </div>
        <p style="color:var(--text-secondary); font-size:0.9rem; margin-top:0.5rem;">
          You're on the <strong>${escapeHtml(currentUser?.plan || 'free')}</strong> plan. Limits reset every 24 hours.
        </p>
      </div>
    `;
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function isRealKey(key, validPrefix) {
  if (!key || typeof key !== 'string') return false;
  if (key.includes('your_')) return false; // placeholder
  if (!key.startsWith(validPrefix)) return false; // wrong format
  return true;
}

function getUsagePercent(used, limit) {
  if (!isFinite(limit)) return 0;
  return Math.min(100, (used / limit) * 100);
}

function getUsageClass(used, limit) {
  if (!isFinite(limit)) return '';
  const ratio = used / limit;
  if (ratio >= 1) return 'danger';
  if (ratio >= 0.75) return 'warning';
  return '';
}

async function payWithStripe(planId) {
  try {
    const data = await apiPost('/api/payments/stripe/create-checkout-session', { plan: planId });
    if (data.url) {
      window.location.href = data.url;
    } else {
      showToast('Stripe is not fully configured.', 'error');
    }
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function payWithRazorpay(planId, planName, planPrice) {
  try {
    const config = window.astraPaymentConfig;
    if (!config.razorpayKeyId) {
      return showToast('Razorpay is not configured.', 'error');
    }

    await loadScript('https://checkout.razorpay.com/v1/checkout.js');
    const order = await apiPost('/api/payments/razorpay/create-order', { plan: planId });

    const options = {
      key: config.razorpayKeyId,
      amount: order.amount,
      currency: order.currency,
      name: 'Lore.Ai',
      description: `${planName} Subscription`,
      order_id: order.orderId,
      handler: async function(response) {
        try {
          await apiPost('/api/payments/razorpay/verify', {
            orderId: response.razorpay_order_id,
            paymentId: response.razorpay_payment_id,
            signature: response.razorpay_signature,
            plan: planId
          });
          showToast('Payment successful! Plan upgraded.', 'success');
          navigate('subscriptions');
        } catch (err) {
          showToast(err.message, 'error');
        }
      },
      prefill: {
        name: currentUser?.name || '',
        email: currentUser?.email || ''
      },
      theme: { color: '#19c37d' }
    };

    const rzp = new window.Razorpay(options);
    rzp.on('payment.failed', function(response) {
      showToast('Payment failed: ' + response.error.description, 'error');
    });
    rzp.open();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function loadScript(src) {
  return new Promise((resolve, reject) => {
    if (document.querySelector(`script[src="${src}"]`)) return resolve();
    const script = document.createElement('script');
    script.src = src;
    script.onload = resolve;
    script.onerror = reject;
    document.head.appendChild(script);
  });
}

// Chat functions
async function loadHistory() {
  try {
    const sessions = await apiGet('/api/chat/sessions');
    const list = document.getElementById('history-list');
    if (!list) return;

    if (sessions.length === 0) {
      list.innerHTML = '<div class="text-center" style="padding:1rem; color:var(--text-secondary);">No chats yet</div>';
      return;
    }

    list.innerHTML = sessions.map(s => `
      <div class="history-item ${s.id === currentSessionId ? 'active' : ''}" onclick="openSession(${s.id})">
        <span>${escapeHtml(s.title)}</span>
        <button class="history-delete" onclick="event.stopPropagation(); deleteSession(${s.id})">🗑</button>
      </div>
    `).join('');
  } catch (err) {
    console.error('Failed to load history:', err);
  }
}

async function createNewSession() {
  try {
    const session = await apiPost('/api/chat/sessions', {});
    currentSessionId = session.id;
    await loadHistory();
    openSession(session.id);
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function openSession(id) {
  currentSessionId = id;
  document.querySelectorAll('.history-item').forEach(el => el.classList.remove('active'));
  const active = document.querySelector(`.history-item[onclick="openSession(${id})"]`);
  if (active) active.classList.add('active');

  const messagesEl = document.getElementById('messages');
  messagesEl.innerHTML = '<div class="empty-state"><div class="spinner"></div></div>';

  try {
    const messages = await apiGet(`/api/chat/sessions/${id}/messages`);
    messagesEl.innerHTML = '';
    if (messages.length === 0) {
      messagesEl.innerHTML = `
        <div class="empty-state">
          <h1>Lore.Ai</h1>
          <p>Start a new conversation</p>
        </div>
      `;
    } else {
      messages.forEach(m => appendMessage(m.role, m.content, m.type, m.attachment_url, false));
    }
    scrollToBottom();
  } catch (err) {
    messagesEl.innerHTML = `<div class="empty-state"><p>${err.message}</p></div>`;
  }
}

async function deleteSession(id) {
  if (!confirm('Delete this chat?')) return;
  try {
    await apiDelete(`/api/chat/sessions/${id}`);
    if (currentSessionId === id) currentSessionId = null;
    await loadHistory();
    if (!currentSessionId) createNewSession();
    showToast('Chat deleted', 'success');
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function sendMessage() {
  const input = document.getElementById('chat-input');
  const content = input.value.trim();
  if (!content && !currentAttachment) return;

  input.value = '';
  autoResize(input);
  clearAttachment();

  const messagesEl = document.getElementById('messages');
  if (messagesEl.querySelector('.empty-state')) messagesEl.innerHTML = '';

  appendMessage('user', content || '(attached image)', 'text', currentAttachment?.url);
  appendTyping();
  scrollToBottom();

  try {
    const data = await apiPost(`/api/chat/sessions/${currentSessionId}/messages`, {
      content: content || 'Describe this image',
      attachment_url: currentAttachment?.url || null
    });
    removeTyping();
    appendMessage('assistant', data.assistantMessage.content, 'text');
    await loadHistory();
  } catch (err) {
    removeTyping();
    appendMessage('assistant', `⚠️ ${err.message}`, 'text');
  }
  scrollToBottom();
}

function appendMessage(role, content, type = 'text', attachmentUrl = null, animate = false) {
  const messagesEl = document.getElementById('messages');
  if (messagesEl.querySelector('.empty-state')) messagesEl.innerHTML = '';

  const div = document.createElement('div');
  div.className = `message ${role}`;

  let innerContent = '';
  if (type === 'image' || attachmentUrl) {
    const mediaUrl = type === 'image' ? content : attachmentUrl;
    innerContent = `<img src="${escapeHtml(mediaUrl)}" alt="Attached image" />`;
  } else if (type === 'video') {
    innerContent = `<video controls src="${escapeHtml(content)}"></video>`;
  } else {
    innerContent = `<p>${escapeHtml(content)}</p>`;
  }

  div.innerHTML = `
    <div class="message-avatar">${role === 'assistant' ? '✨' : (currentUser?.name || 'U').charAt(0).toUpperCase()}</div>
    <div class="message-content">${innerContent}</div>
  `;

  messagesEl.appendChild(div);
  if (animate) {
    div.style.opacity = '0';
    div.style.transform = 'translateY(10px)';
    div.style.transition = 'all 0.3s ease';
    setTimeout(() => {
      div.style.opacity = '1';
      div.style.transform = 'translateY(0)';
    }, 10);
  }
}

function appendTyping() {
  const messagesEl = document.getElementById('messages');
  const div = document.createElement('div');
  div.className = 'message assistant';
  div.id = 'typing-indicator';
  div.innerHTML = `
    <div class="message-avatar">✨</div>
    <div class="message-content">
      <div class="typing-indicator"><span></span><span></span><span></span></div>
    </div>
  `;
  messagesEl.appendChild(div);
}

function removeTyping() {
  const el = document.getElementById('typing-indicator');
  if (el) el.remove();
}

function scrollToBottom() {
  const messagesEl = document.getElementById('messages');
  if (messagesEl) messagesEl.scrollTop = messagesEl.scrollHeight;
}

function handleInputKey(e) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
}

function autoResize(textarea) {
  textarea.style.height = 'auto';
  textarea.style.height = Math.min(textarea.scrollHeight, 200) + 'px';
}

function setInput(text) {
  const input = document.getElementById('chat-input');
  if (input) {
    input.value = text;
    input.focus();
    autoResize(input);
  }
}

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}

function escapeHtml(text) {
  if (!text) return '';
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// Media generation
function toggleMediaMenu() {
  const menu = document.getElementById('media-menu');
  mediaMenuOpen = !mediaMenuOpen;
  menu.classList.toggle('show', mediaMenuOpen);
}

async function generateImageFromInput() {
  const input = document.getElementById('chat-input');
  const prompt = input.value.trim();
  if (!prompt) return showToast('Type an image prompt first', 'warning');
  toggleMediaMenu();
  input.value = '';
  autoResize(input);

  const messagesEl = document.getElementById('messages');
  if (messagesEl.querySelector('.empty-state')) messagesEl.innerHTML = '';
  appendMessage('user', `🎨 Generate image: ${prompt}`, 'text');
  appendTyping();
  scrollToBottom();

  try {
    const data = await apiPost('/api/media/generate/image', { prompt });
    removeTyping();
    appendMessage('assistant', data.url, 'image');
    appendMessage('assistant', `Generated image for "${prompt}". Remaining today: ${data.remaining}`, 'text');
  } catch (err) {
    removeTyping();
    appendMessage('assistant', `⚠️ ${err.message}`, 'text');
  }
  scrollToBottom();
}

async function generateVideoFromInput() {
  const input = document.getElementById('chat-input');
  const prompt = input.value.trim();
  if (!prompt) return showToast('Type a video prompt first', 'warning');
  toggleMediaMenu();
  input.value = '';
  autoResize(input);

  const messagesEl = document.getElementById('messages');
  if (messagesEl.querySelector('.empty-state')) messagesEl.innerHTML = '';
  appendMessage('user', `🎬 Generate video: ${prompt}`, 'text');
  appendTyping();
  scrollToBottom();

  try {
    const data = await apiPost('/api/media/generate/video', { prompt, source: 'text' });
    removeTyping();
    appendMessage('assistant', data.url, 'video');
    appendMessage('assistant', `Generated video for "${prompt}". Remaining today: ${data.remaining}`, 'text');
  } catch (err) {
    removeTyping();
    appendMessage('assistant', `⚠️ ${err.message}`, 'text');
  }
  scrollToBottom();
}

async function handlePhotoToVideo(e) {
  const file = e.target.files[0];
  if (!file) return;

  const messagesEl = document.getElementById('messages');
  if (messagesEl.querySelector('.empty-state')) messagesEl.innerHTML = '';

  // Preview upload locally first
  const localUrl = URL.createObjectURL(file);
  appendMessage('user', '🖼️ Create video from this photo:', 'text', localUrl);
  appendTyping();
  scrollToBottom();

  try {
    const formData = new FormData();
    formData.append('image', file);
    const data = await apiUpload('/api/media/generate/photo-to-video', formData);
    removeTyping();
    appendMessage('assistant', data.url, 'video');
    appendMessage('assistant', `Generated video from your photo. Remaining today: ${data.remaining}`, 'text');
  } catch (err) {
    removeTyping();
    appendMessage('assistant', `⚠️ ${err.message}`, 'text');
  }
  scrollToBottom();
}

async function handleImageUpload(e) {
  const file = e.target.files[0];
  if (!file) return;

  try {
    const formData = new FormData();
    formData.append('image', file);
    const data = await apiUpload('/api/media/upload', formData);
    currentAttachment = { url: data.url, file };
    showAttachmentPreview(data.url);
    showToast('Photo attached', 'success');
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function showAttachmentPreview(url) {
  const preview = document.getElementById('attachment-preview');
  preview.classList.remove('hidden');
  preview.innerHTML = `
    <div class="attachment-preview">
      <img src="${escapeHtml(url)}" alt="attachment" />
      <span>Photo attached</span>
      <button class="remove-attachment" onclick="clearAttachment()">✕</button>
    </div>
  `;
}

function clearAttachment() {
  currentAttachment = null;
  const preview = document.getElementById('attachment-preview');
  if (preview) {
    preview.classList.add('hidden');
    preview.innerHTML = '';
  }
  const input = document.getElementById('image-input');
  if (input) input.value = '';
}

// Voice chat
function setupVoiceRecognition() {
  if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
    const btn = document.getElementById('voice-btn');
    if (btn) {
      btn.title = 'Voice chat not supported in this browser';
      btn.style.opacity = '0.5';
    }
    return;
  }

  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = true;
  recognition.lang = 'en-US';

  recognition.onresult = (event) => {
    const transcript = Array.from(event.results)
      .map(r => r[0].transcript)
      .join('');
    const input = document.getElementById('chat-input');
    if (input) input.value = transcript;
    autoResize(input);
  };

  recognition.onerror = (event) => {
    console.error('Voice error:', event.error);
    showToast('Voice recognition error: ' + event.error, 'error');
    stopVoice();
  };

  recognition.onend = () => {
    if (isRecording) stopVoice();
  };
}

function toggleVoice() {
  if (!recognition) {
    showToast('Voice chat is not supported in your browser.', 'error');
    return;
  }
  if (isRecording) {
    recognition.stop();
    stopVoice();
  } else {
    recognition.start();
    isRecording = true;
    document.getElementById('voice-btn').classList.add('recording');
    showToast('Listening... speak now', 'success');
  }
}

function stopVoice() {
  isRecording = false;
  const btn = document.getElementById('voice-btn');
  if (btn) btn.classList.remove('recording');
}

// Start the app
document.addEventListener('DOMContentLoaded', init);
